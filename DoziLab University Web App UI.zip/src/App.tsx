import { useState } from "react";
import { Dashboard } from "./components/Dashboard";
import { Courses } from "./components/Courses";
import { AppStore } from "./components/AppStore";
import { DeploymentWizard } from "./components/DeploymentWizard";
import { OpenStackConfig } from "./components/OpenStackConfig";
import { Sidebar } from "./components/Sidebar";
import { Login } from "./components/Login";
import logo from "figma:asset/5c87f57a05de8f8018669c9004318908d006dcd5.png";

type View =
  | "dashboard"
  | "courses"
  | "appstore"
  | "deployment"
  | "config";

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [currentView, setCurrentView] =
    useState<View>("dashboard");
  const [deploymentActive, setDeploymentActive] =
    useState(false);

  const handleLogin = () => {
    setIsAuthenticated(true);
  };

  const handleStartDeployment = () => {
    setDeploymentActive(true);
    setCurrentView("deployment");
  };

  const handleCancelDeployment = () => {
    setDeploymentActive(false);
    setCurrentView("appstore");
  };

  const handleCompleteDeployment = () => {
    setDeploymentActive(false);
    setCurrentView("dashboard");
  };

  const renderView = () => {
    if (deploymentActive) {
      return (
        <DeploymentWizard
          onCancel={handleCancelDeployment}
          onComplete={handleCompleteDeployment}
        />
      );
    }

    switch (currentView) {
      case "dashboard":
        return <Dashboard />;
      case "courses":
        return <Courses />;
      case "appstore":
        return <AppStore onDeploy={handleStartDeployment} />;
      case "config":
        return <OpenStackConfig />;
      default:
        return <Dashboard />;
    }
  };

  // Show login page if not authenticated
  if (!isAuthenticated) {
    return <Login onLogin={handleLogin} logo={logo} />;
  }

  return (
    <div className="flex h-screen bg-slate-50">
      <Sidebar
        currentView={currentView}
        onViewChange={setCurrentView}
        logo={logo}
        deploymentActive={deploymentActive}
      />
      <main className="flex-1 overflow-auto">
        {renderView()}
      </main>
    </div>
  );
}